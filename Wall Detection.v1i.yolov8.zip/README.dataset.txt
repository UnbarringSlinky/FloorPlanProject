# Wall Detection > 2023-07-25 3:29pm
https://universe.roboflow.com/walldetection/wall-detection-auqa7

Provided by a Roboflow user
License: Public Domain

